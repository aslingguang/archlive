tree-sitter-css
===============

[![Build Status](https://travis-ci.org/tree-sitter/tree-sitter-css.svg?branch=master)](https://travis-ci.org/tree-sitter/tree-sitter-css)
[![Build status](https://ci.appveyor.com/api/projects/status/smdphgf4ns9jglw5/branch/master?svg=true)](https://ci.appveyor.com/project/maxbrunsfeld/tree-sitter-css/branch/master)

CSS grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).

References

* [CSS Syntax Guide](https://developer.mozilla.org/en-US/docs/Web/CSS/Syntax)
