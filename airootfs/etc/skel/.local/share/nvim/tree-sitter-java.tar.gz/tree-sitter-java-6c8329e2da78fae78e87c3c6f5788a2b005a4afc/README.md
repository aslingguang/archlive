tree-sitter-java
================

[![CI](https://github.com/tree-sitter/tree-sitter-java/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-java/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

Java grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).
