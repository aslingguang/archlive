tree-sitter-cpp
==================

[![Build Status](https://travis-ci.org/tree-sitter/tree-sitter-cpp.svg?branch=master)](https://travis-ci.org/tree-sitter/tree-sitter-cpp)
[![Build status](https://ci.appveyor.com/api/projects/status/fbj5gq4plxaiakiw/branch/master?svg=true)](https://ci.appveyor.com/project/maxbrunsfeld/tree-sitter-cpp/branch/master)

C++ grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).

# References

* [Hyperlinked C++ BNF Grammar](http://www.nongnu.org/hcb/)
* [EBNF Syntax: C++](http://www.externsoft.ch/download/cpp-iso.html)
